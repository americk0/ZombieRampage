
"use strict";

var gl,
	background_program,
	billboard_program,
	horizon_coords,
	horizon_colors,
	billboard_coords,
	fov = 60,
	canvas,
	keysPressed = [],
	trans_mat = [],
	rot_mat = [],
	transform_coords = [],
	textures = {},
	//texture,
	random_list;

window.onload = function init(){
	canvas = document.getElementById('gl-canvas');

	gl = WebGLUtils.setupWebGL(canvas);
	if(!gl){ alert('WebGL is not supported'); }

	gl.viewport(0, 0, canvas.width, canvas.height);
	gl.clearColor(1.0, 1.0, 1.0, 1.0);

	//initialize shaders
	background_program = initShaders(gl, "vertex-shader-horizon", "fragment-shader-horizon");
	billboard_program = initShaders(gl, "vertex-shader-billboard", "fragment-shader-billboard");


	//initialize game object coordinates
	initHorizon();
	billboard_coords = genPoints(20);
	//random_list = genRandom(20, 0.5);

	//load images
	//load_texture('house_1.png', 'one');
	//load_texture('house_2.png', 'two');

	//allow for transparent images
	gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
	gl.enable(gl.BLEND);

	//add listeners for key input
	window.addEventListener('keydown', function(event){
		keysPressed[event.keyCode] = true;
	});
	window.addEventListener('keyup', function(event){
		keysPressed[event.keyCode] = false;
	});

	load_textures(
		['house_1.png', 'house_2.png'],
		['house_1', 'house_2'],
		render
	);
}

/**
 *	initializes the coordinates for the horizon triangles and the colors of
 *	each vertex
 */
function initHorizon(){
	horizon_coords = [
		new vec2(-1, 0), new vec2(-1, -1), new vec2(1, -1),
		new vec2(-1, 0), new vec2(1, 0), new vec2(1, -1),
		new vec2(-1, 1), new vec2(-1, 0), new vec2(1, 0),
		new vec2(-1, 1), new vec2(1, 1), new vec2(1, 0)
	];
	horizon_colors = [
		new vec4(1.0, 1.0, 1.0, 1.0), new vec4(0.0, 1.0, 0.0, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
		new vec4(1.0, 1.0, 1.0, 1.0), new vec4(1.0, 1.0, 1.0, 1.0), new vec4(0.0, 1.0, 0.0, 1.0),
		new vec4(0.0, 1.0, 1.0, 1.0), new vec4(1.0, 1.0, 1.0, 1.0), new vec4(1.0, 1.0, 1.0, 1.0),
		new vec4(0.0, 1.0, 1.0, 1.0), new vec4(0.0, 1.0, 1.0, 1.0), new vec4(1.0, 1.0, 1.0, 1.0)
	];
}

/**
 *	loads the texture specified into the program and sets it as the 'current'
 *	texture
 *
 *	@param {string} source - the path to the image to load
 *	@param {string} name - the name used to store/recall the image
 */
/*
function load_texture(source, name) {
	textures[name]= gl.createTexture();
	textures[name].image = new Image();
	textures[name].image.onload = function() {
		gl.bindTexture(gl.TEXTURE_2D, textures[name]);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, this);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
	}
	textures[name].image.src = source;
}
*/

/**
 *	loads the textures/images from the specified urls
 *
 *	@param {string[]} sources - an array of image urls
 *	@param {string[]} names - an array of names to associate with each respective url
 *	@param {function} callback - a function to call after the textures are loaded
 */
function load_textures(sources, names, callback){
	load_images(sources, function(images){
		for(var i=0; i<images.length; i++){
			var texture = gl.createTexture();
			texture.image = images[i];
			gl.bindTexture(gl.TEXTURE_2D, texture);
			gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
			gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, images[i]);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
			gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
			textures[names[i]] = texture;
		}
		callback();
	});
}

/**
 *	loads an image from the specified source and then calls the callback function
 *
 *	@param {string} source - the url for the image to load
 *	@param {function} callback - the function to call after the image loads
 *	@return {Image} the image that was loaded
 */
function load_image(source, callback){
	var image = new Image();
	image.onload = callback;
	image.src = source;
	return image;
}

/**
 *	loads a series of images and then calls the specified callback function
 *
 *	@param {string[]} sources - the array of url strings for the images to load
 *	@param {function} callback -
 */
function load_images(sources, callback){
	var images = [];
	var numImagesLeft, numImages;
	numImagesLeft = numImages = sources.length;

	for(var i=0; i<numImages; i++){
		images.push(load_image(sources[i], function(){
			--numImagesLeft;
			if(numImagesLeft == 0){
				callback(images);
			}
		}));
	}
}

/**
 *	sets the image with the specified name as the current image
 *
 *	@param {string} name - the name of the image to use
 */
function useTexture(name){
	gl.bindTexture(gl.TEXTURE_2D, textures[name]);
}

/**
 *	creates the vertices for a billboard image at the specified coordinates
 *
 *	@param {Array} position - the array containing the vertices
 *	@param {number} position[0] - the x coordinate
 *	@param {number} position[1] - the y coordinate
 *	@param {number} position[2] - the z coordinate
 *	@returns {Object} the object containing the vertices and texture coordinates for the billboard
 */
function create_billboard(position){
	// the vertices define two triangles on the z=0 plane
	var vertices = [new vec4(-1, -1, 0, 1), new vec4(1, -1, 0, 1), new vec4(-1 , 1, 0, 1), new vec4(1, -1, 0, 1), new vec4(-1, 1, 0, 1), new vec4(1, 1, 0, 1)];
	// we translate the billboard to the position of the object in the world
	var trans = translate(position[0], 0, position[2]);
	// we shrink it using a scale matrix
	var sc = scalem(0.05, 0.05, 0.05);
	// apply the above transformations to all 6 vertices of our billboard
	for(var i=0; i <6; i++){
		vertices[i] = vecMatMult(vertices[i], sc); // scale
		vertices[i] = vecMatMult(vertices[i], trans); // translate
	}
	// define texture coordinates
	var textureCoords = [new vec2(0, 0), new vec2(1, 0), new vec2(0, 1), new vec2(1, 0), new vec2(0, 1), new vec2(1, 1)];
	// create an empty object
	var ret = {};
	// add properties to object and return
	ret.vertices = vertices ;
	ret.textureCoords = textureCoords ;
	return ret ;
}

//no longer needed
/**
 *	generates a list of the given size, each element is randomly made either 1 or 0
 *
 *	@param {number} size - the number of elements to generate
 *	@param {number} chance - the percent chance (0 <= chance <= 1) that an element is 1
 *	@return {Array} a list of 1s and 0s
 */
function genRandom(size, chance){
	var list = [];
	for(var i=0; i<size; i++){
		if(Math.random() < chance){
			list.push(1);
		}else{
			list.push(0);
		}
	}
	return new Float32Array(list);
}

/**
 *	Generates a specified number of random points on the xz-plane
 *
 *	@param {number} numPoints - the number of points to generate
 *	@returns {Array} the array containing the specified number of vec4's for each randomly generated point
 */
function genPoints(numPoints){
	var points = [];
	for(var i=0; i<numPoints; i++){
		points.push(new vec4(
			(Math.random() * 2.0) - 1.0,
			0,
			(Math.random() * 2.0) - 1.0,
			 1));
	}
	return points;
}

/**
 *	Creates an array of billboard coordinates and texture coordinates
 *
 *	@param {Array} points - an array of vec4's containing the points for billboards
 *	@returns {Object} an object containing an array of billboard coordinates and texture coordinates
 */
function get_billboard_coords(points){
	var vertices = [];
	var textureCoords = [];
	for(var i=0; i<points.length; i++){
		var current = create_billboard(points[i]);
		vertices = vertices.concat(current.vertices);
		textureCoords = textureCoords.concat(current.textureCoords);
	}
	return {vertices: vertices, textureCoords: textureCoords};
}

/**
 *	multiplies a matrix by a vector
 *
 *	@param {vec4} vec - the vector to multiply
 *	@param {mat4} mat - the matrix to multiply by
 *	@returns {vec4} the vector containing the result of multiplication
 */
function vecMatMult(vec, mat){
	var res = vec4();
	res[0] = mat[0][0] * vec[0] + mat[0][1] * vec[1] + mat[0][2] * vec[2] + mat[0][3] * vec[3];
	res[1] = mat[1][0] * vec[0] + mat[1][1] * vec[1] + mat[1][2] * vec[2] + mat[1][3] * vec[3];
	res[2] = mat[2][0] * vec[0] + mat[2][1] * vec[1] + mat[2][2] * vec[2] + mat[2][3] * vec[3];
	res[3] = mat[3][0] * vec[0] + mat[3][1] * vec[1] + mat[3][2] * vec[2] + mat[3][3] * vec[3];
	return res;
}

/**
 *	constructs translation/rotation matrices for movement based on input keys
 */
function handle_input(){
	trans_mat = new mat4(
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	);
	rot_mat = new mat4(
		1, 0, 0, 0,
		0, 1, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	);
	if(keysPressed[65]){ //left
		rot_mat = rotate(-2, new vec4(0, 1, 0, 0));
	}
	else if(keysPressed[68]){ //right
		rot_mat = rotate(2, new vec4(0, 1, 0, 0));
	}
	if(keysPressed[87]){ //forward
		trans_mat[2][3] += 0.005;
	}
	if(keysPressed[83]){ //backwards
		trans_mat[2][3] += -0.005;
	}
	if(keysPressed[69]){ //strafe-left
		trans_mat[0][3] += -0.005;
	}
	if(keysPressed[81]){ //strafe-right
		trans_mat[0][3] += 0.005;
	}
}

/**
 *	moves all points in the game (stored in transform_coords) according to the matrices generated from key input
 */
function transform_geometry(){
	for(var i=0; i<transform_coords.length; i++){
		for(var j=0; j<transform_coords[i].length; j++){
			transform_coords[i][j] = vecMatMult(transform_coords[i][j], trans_mat);
			transform_coords[i][j] = vecMatMult(transform_coords[i][j], rot_mat);
		}
	}
}

/**
 *	Draws the game
 */
function render(){
	//gl.clear(gl.COLOR_BUFFER_BIT);
	gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);

	drawHorizon();

	handle_input();

	transform_coords[0] = billboard_coords;
	transform_geometry();
	billboard_coords = transform_coords[0];

	drawBillboards();

	requestAnimFrame(render);
}

/**
 *	sends data to the GPU for the horizon to be drawn
 */
function drawHorizon(){
	gl.useProgram(background_program);

	var bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(horizon_coords), gl.STATIC_DRAW);

	var vPosition = gl.getAttribLocation(background_program, "vPosition");
	gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);

	bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(horizon_colors), gl.STATIC_DRAW);

	var vColor = gl.getAttribLocation(background_program, 'vColor');
	gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vColor);

	gl.disable(gl.DEPTH_TEST);
	gl.drawArrays(gl.TRIANGLES, 0, 12);

	gl.enable(gl.DEPTH_TEST);
}

/**
 *	sends data to the GPU for the billboard images to be drawn
 */
function drawBillboards(){
	gl.useProgram(billboard_program);

	var projection = perspective(fov, canvas.width/canvas.height, 0.001, 100);
	var address = gl.getUniformLocation(billboard_program, 'projection');
	gl.uniformMatrix4fv(address, false, flatten(projection));

	var coords = get_billboard_coords(billboard_coords);
	var numPoints = coords.vertices.length;
	var list1 = { //first half of coordinates
		vertices: coords.vertices.slice(0, numPoints/2),
		textureCoords: coords.textureCoords.slice(0, numPoints/2)
	};
	var list2 = { //second half of coordinates
		vertices: coords.vertices.slice(numPoints/2, numPoints),
		textureCoords: coords.textureCoords.slice(numPoints/2, numPoints)
	};

	var bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(list1.vertices), gl.STATIC_DRAW);

	var vPosition = gl.getAttribLocation(billboard_program, "vPosition");
	gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);

	bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(list1.textureCoords), gl.STATIC_DRAW);

	var vTextureCoord = gl.getAttribLocation(billboard_program, "vTextureCoord");
	gl.vertexAttribPointer(vTextureCoord, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vTextureCoord);

  gl.clear(gl.DEPTH_BUFFER_BIT);
	useTexture('house_1');
	gl.drawArrays(gl.TRIANGLES, 0, numPoints/2);

	//draw yellow houses
	bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(list2.vertices), gl.STATIC_DRAW);

	vPosition = gl.getAttribLocation(billboard_program, "vPosition");
	gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);

	bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	gl.bufferData(gl.ARRAY_BUFFER, flatten(list2.textureCoords), gl.STATIC_DRAW);

	vTextureCoord = gl.getAttribLocation(billboard_program, "vTextureCoord");
	gl.vertexAttribPointer(vTextureCoord, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vTextureCoord);

	useTexture('house_2');
	gl.drawArrays(gl.TRIANGLES, 0, numPoints/2);
}
